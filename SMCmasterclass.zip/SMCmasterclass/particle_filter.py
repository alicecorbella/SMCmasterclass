import numpy as np
import matplotlib.pyplot as plt

def gaussian_pdf(x, mu, sigma):

    return (1/(sigma*np.sqrt(2*np.pi)))*np.exp(-(0.5)*(( x- mu)/sigma)**2)

class kernel_proposal():

    def __init__(self, phi, sigma):

        self.phi   = phi
        self.sigma = sigma

    def rstate_0(self, N = 1):
    
        return np.random.normal(0, self.sigma, size = (N))

    def dstate_0(self, x_0):
    
        return gaussian_pdf(x_0, 0, self.sigma) 

    def rstate(self, x_tm1):
    
        return np.random.normal(self.phi*x_tm1, self.sigma*np.ones(len(x_tm1)))

    def dstate(self, x_tm1, x_t):

        return gaussian_pdf(x_t, self.phi*x_tm1, self.sigma) 

class bad_proposal():
    
    def __init__(self, sigma):

        self.sigma = sigma

    def rstate_0(self, N = 1):
    
        return np.random.normal(-1, self.sigma, size = (N))

    def dstate_0(self, x_0):
    
        return gaussian_pdf(x_0, 0, self.sigma) 

    def rstate(self, x_tm1):
    
        return np.random.normal(-1, self.sigma*np.ones(len(x_tm1)))

    def dstate(self, x_tm1, x_t):

        return gaussian_pdf(x_t, -1, self.sigma) 
        
class bad_proposal_impoverishment():
    
    def __init__(self, sigma):

        self.sigma = sigma

    def rstate_0(self, N = 1):
    
        return np.random.normal(0, self.sigma, size = (N))

    def dstate_0(self, x_0):
    
        return gaussian_pdf(x_0, 0, self.sigma) 

    def rstate(self, x_tm1):
    
        return x_tm1

    def dstate(self, x_tm1, x_t):

        return np.ones(x_tm1.shape) 

class particle_filter():

    def __init__(self, proposal, model, N):

        self.proposal = proposal
        self.model    = model
        self.N        = N

    def weigth_0(self, x_t):

        initial_distribution = self.model.dstate_0(x_t)
        proposal             = self.proposal.dstate_0(x_t)

        weigths = initial_distribution/proposal

        return weigths, weigths/np.sum(weigths)

    def weigth(self, x_tm1, x_t, y_t):

        kernel   = self.model.dstate(x_tm1, x_t)
        emission = self.model.dobs(x_t, y_t)
        proposal = self.proposal.dstate(x_tm1, x_t)

        weigths = kernel*emission/proposal

        return weigths, weigths/np.sum(weigths)

    def resampling(self, W, x_t):

        index     = np.linspace(0, self.N-1, self.N, dtype = np.int)
        ancestors = np.random.choice(index, size=len(W), replace=True, p=W)

        return x_t[ancestors]

    def run_plot(self, y):

        scale = 10

        times = np.ones((1,3))*np.linspace(0, len(y), len(y)+1).reshape(len(y)+1, 1)
        times[:,1] = times[:,1] + 0.33
        times[:,2] = times[:,2] + 0.66

        x_tm1      = self.proposal.rstate_0(self.N)
        plt.scatter(np.ones(x_tm1.shape)*times[0,0], x_tm1, color = "grey", s = scale*1)

        W_t, w_t = self.weigth_0(x_tm1)
        plt.scatter(np.ones(x_tm1.shape)*times[0,1], x_tm1, color = "red", s = self.N*scale*w_t)

        x_tm1      = self.resampling(w_t, x_tm1)
        plt.scatter(np.ones(x_tm1.shape)*times[0,2], x_tm1, color = "green", s = scale*1)

        x = (x_tm1).reshape(self.N, 1)
        W = (W_t).reshape(self.N, 1)

        for t in range(1, len(y)+1):

            x_t = self.proposal.rstate(x_tm1)
            plt.scatter(np.ones(x_t.shape)*times[t,0], x_t, color = "grey", s = scale*1)

            W_t, w_t = self.weigth(x_tm1, x_t, y[t-1])
            plt.scatter(np.ones(x_tm1.shape)*times[t,1], x_t, color = "red", s = self.N*scale*w_t)
            x_tm1    = self.resampling(w_t, x_t)

            plt.scatter(np.ones(x_tm1.shape)*times[t,2], x_tm1, color = "green", s = scale*1 )

            x = np.concatenate((x, (x_tm1).reshape(self.N, 1)), axis =1)
            W = np.concatenate((W, (W_t).reshape(self.N, 1)),   axis =1)

        return x, W

    def step_0(self):

        x_tm1      = self.proposal.rstate_0(self.N)
        W_t, w_t = np.ones(x_tm1.shape), np.ones(x_tm1.shape)/self.N

        L_t = np.mean(W_t)

        return x_tm1, L_t

    def step(self, x_tm1, y_t):

        x_t = self.proposal.rstate(x_tm1)

        W_t, w_t = self.weigth(x_tm1, x_t, y_t)
        L_update = np.mean(W_t)

        x_t    = self.resampling(w_t, x_t)

        return x_t, L_update

    def run(self, y):

        x_tm1, L_t = self.step_0()

        x = (x_tm1).reshape(self.N, 1)

        for t in range(1, len(y)+1):

            x_tm1, L_update = self.step(x_tm1, y[t-1])

            L_t = L_t*L_update
            x = np.concatenate((x, (x_tm1).reshape(self.N, 1)), axis =1)

        return x, L_t






    

