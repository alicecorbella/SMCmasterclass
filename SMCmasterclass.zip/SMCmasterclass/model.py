import numpy as np

def gaussian_pdf(x, mu, sigma):

    return (1/(sigma*np.sqrt(2*np.pi)))*np.exp(-(0.5)*(( x- mu)/sigma)**2)

def log_gaussian_pdf(x, mu, sigma):

    return -np.log(sigma) - np.log(np.sqrt(2*np.pi)) -(0.5)*(( x- mu)/sigma)**2


class stochastic_volatility():

    def __init__(self, phi, sigma, beta):

        self.phi   = phi
        self.sigma = sigma
        self.beta  = beta

    def rstate_0(self):

        return np.random.normal(0, self.sigma, 1)

    def dstate_0(self, x_0):
    
        return gaussian_pdf(x_0, 0, self.sigma) 

    def rstate(self, x_tm1):

        return np.random.normal(self.phi*x_tm1, self.sigma, 1)

    def dstate(self, x_tm1, x_t):

        return gaussian_pdf(x_t, self.phi*x_tm1, self.sigma) 

    def robs(self, x_t):

        return np.random.normal(0, self.beta*np.sqrt(np.exp(x_t)), 1)

    def dobs(self, x_t, y_t):

        return gaussian_pdf(y_t, 0, self.beta*np.sqrt(np.exp(x_t)))

    def ldobs(self, x_t, y_t):
    
        return log_gaussian_pdf(y_t, 0, self.beta*np.sqrt(np.exp(x_t)))

    def run(self, T):

        x_t = self.rstate_0()
        # y_t = self.robs(x) 

        x = np.array(x_t)
        y = np.array([0.0])
        # y.append(y_t)

        for t in range(1, T):

            x_t = np.array(self.rstate(x_t))
            y_t = np.array(self.robs(x_t))

            x   = np.concatenate((x, x_t), axis = 0) 
            y   = np.concatenate((y, y_t), axis = 0) 

        return x, y[1:]

    