from pyexpat import model
from tkinter import W
import numpy as np
from scipy.stats import gamma, beta

from particle_filter import kernel_proposal

def select(object_tilde, object_, accept_tilde):
    if accept_tilde:
        return object_tilde
    else:
        return object_

def ESS(W):

    return ((np.sum(W))**2)/(np.sum(W**2))

class Gamma_prior():

    def __init__(self, alpha, beta):
        self.a     = alpha
        self.scale = 1/beta

    def sample(self, N_theta):

        return np.random.gamma(self.a, self.scale, N_theta)

    def pdf(self, theta):

        return gamma.pdf(theta, self.a, 0, self.scale)


class Beta_prior():

    def __init__(self, a, b):
        self.a = a
        self.b = b

    def sample(self, N_theta):

        return np.random.beta(self.a, self.b, N_theta)

    def pdf(self, theta):

        return beta.pdf(theta, self.a, self.b)

class theta_proposal():

    def __init__(self, std):

        self.std = std

    def sample(self, theta):

        return np.random.normal(theta, self.std)

    def pdf(self, theta, theta_proposed):

        return (1/(self.std*np.sqrt(2*np.pi)))*np.exp(-(0.5)*(( theta- theta_proposed)/self.std)**2)


class SMC2_stochastic_volatility():

    def __init__(self, prior_phi, prior_sigma, prior_beta, proposal_theta, N_theta, N, threshold):

        self.prior_phi   = prior_phi
        self.prior_sigma = prior_sigma
        self.prior_beta  = prior_beta

        self.proposal_theta = proposal_theta

        self.N_theta  = N_theta
        self.N        = N

        self.threshold = threshold

    def resampling(self, w):
    
        index     = np.linspace(0, self.N_theta-1, self.N_theta, dtype = np.int)
        ancestors = np.random.choice(index, size=len(w), replace=True, p=w)

        return ancestors

    def run(self, y):

        phi_par   = self.prior_phi.sample(self.N_theta)
        sigma_par = self.prior_sigma.sample(self.N_theta)
        beta_par  = self.prior_beta.sample(self.N_theta)

        while any(sigma_par<0) or any(beta_par<0):
            print("fake initialization")
            phi_par   = self.prior_phi.sample(self.N_theta)
            sigma_par = self.prior_sigma.sample(self.N_theta)
            beta_par  = self.prior_beta.sample(self.N_theta)         

        W = np.ones(phi_par.shape)
        w = np.ones(phi_par.shape)/self.N_theta

        model    = [stochastic_volatility(phi_par[i], sigma_par[i], beta_par[i]) for i in range(self.N_theta)]
        proposal = [kernel_proposal(phi_par[i], sigma_par[i]) for i in range(self.N_theta)]
        PF       = [particle_filter(proposal[i], model[i], self.N) for i in range(self.N_theta)]

        step_0_output = [PF[i].step_0() for i in range(self.N_theta)]

        x_tm1 = [step_0_output[i][0] for i in range(self.N_theta)]
        L_t   = [step_0_output[i][1] for i in range(self.N_theta)]

        phi_history   = phi_par.reshape((self.N_theta, 1))
        sigma_history = sigma_par.reshape((self.N_theta, 1))
        beta_history  = beta_par.reshape((self.N_theta, 1))

        for t in range(1, len(y)+1):
            
            step_t_output = [PF[i].step(x_tm1[i], y[t-1]) for i in range(self.N_theta)]

            x_tm1     = [step_t_output[i][0] for i in range(self.N_theta)]
            L_update = np.array([step_t_output[i][1] for i in range(self.N_theta)])
            L_t   = [L_t[i]*L_update[i] for i in range(self.N_theta)]

            W = W*L_update
            w = W/np.sum(W)

            if ESS(W)<self.N_theta*self.threshold:

                print(t)
                
                # resampling
                ancestors = self.resampling(w)
                phi_par   = phi_par[ancestors]
                sigma_par = sigma_par[ancestors]
                beta_par  = beta_par[ancestors]

                # mutation
                phi_par_tilde   = self.proposal_theta.sample(phi_par)
                sigma_par_tilde = self.proposal_theta.sample(sigma_par)
                beta_par_tilde  = self.proposal_theta.sample(beta_par)

                while any(sigma_par_tilde<0) or any(beta_par_tilde<0):
                    print("fake mutation")
                    phi_par_tilde   = self.proposal_theta.sample(phi_par)
                    sigma_par_tilde = self.proposal_theta.sample(sigma_par)
                    beta_par_tilde  = self.proposal_theta.sample(beta_par)

                model_tilde    = [stochastic_volatility(phi_par_tilde[i], sigma_par_tilde[i], beta_par_tilde[i]) for i in range(self.N_theta)]
                proposal_tilde = [kernel_proposal(phi_par_tilde[i], sigma_par_tilde[i]) for i in range(self.N_theta)]
                PF_tilde       = [particle_filter(proposal_tilde[i], model_tilde[i], self.N) for i in range(self.N_theta)]

                PF_tilde_output = [PF_tilde[i].run(y[:(t+1)]) for i in range(self.N_theta)]

                x_tm1_tilde = [PF_tilde_output[i][0][:,-1] for i in range(self.N_theta)]
                L_t_tilde   = [PF_tilde_output[i][1] for i in range(self.N_theta)]
                # mutation: MCMC step
                prior_score       = self.prior_beta.pdf(beta_par)*self.prior_sigma.pdf(sigma_par)*self.prior_phi.pdf(phi_par)
                prior_score_tilde = self.prior_beta.pdf(beta_par_tilde)*self.prior_sigma.pdf(sigma_par_tilde)*self.prior_phi.pdf(phi_par_tilde)

                proposal_score_tilde = self.proposal_theta.pdf(beta_par,       beta_par_tilde)*self.proposal_theta.pdf(sigma_par,       sigma_par_tilde)*self.proposal_theta.pdf(phi_par,       phi_par_tilde)
                proposal_score       = self.proposal_theta.pdf(beta_par_tilde, beta_par      )*self.proposal_theta.pdf(sigma_par_tilde, sigma_par      )*self.proposal_theta.pdf(phi_par_tilde, phi_par      )

                alpha  = (prior_score_tilde/prior_score)*(proposal_score_tilde/proposal_score)*(np.array(L_t_tilde)/np.array(L_t))
                accept_tilde = np.random.uniform(0, 1, self.N_theta)<alpha

                # Replacement
                phi_par   = phi_par_tilde*accept_tilde   + phi_par*(1-accept_tilde)   
                sigma_par = sigma_par_tilde*accept_tilde + sigma_par*(1-accept_tilde) 
                beta_par  = beta_par_tilde*accept_tilde  + beta_par*(1-accept_tilde)  

                PF        = [select(PF_tilde[i],    PF[i],    accept_tilde[i]) for i in range(self.N_theta)]
                x_tm1 = [select(x_tm1_tilde[i], x_tm1[i], accept_tilde[i]) for i in range(self.N_theta)]
                L_t       = [select(L_t_tilde[i],   L_t[i],   accept_tilde[i]) for i in range(self.N_theta)]

                W = np.ones(phi_par.shape)
                w = np.ones(phi_par.shape)/self.N_theta

            phi_history   = np.concatenate((phi_history  , phi_par.reshape(  (self.N_theta, 1))), axis = 1)
            sigma_history = np.concatenate((sigma_history, sigma_par.reshape((self.N_theta, 1))), axis = 1)
            beta_history  = np.concatenate((beta_history , beta_par.reshape( (self.N_theta, 1))), axis = 1)

        return phi_history, sigma_history, beta_history, L_t


    
